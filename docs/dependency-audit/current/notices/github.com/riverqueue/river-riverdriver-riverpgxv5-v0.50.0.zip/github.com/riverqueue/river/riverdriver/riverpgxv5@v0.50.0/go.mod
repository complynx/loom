module github.com/riverqueue/river/riverdriver/riverpgxv5

go 1.26.0

toolchain go1.26.6

require (
	github.com/jackc/pgx/v5 v5.11.0
	github.com/jackc/puddle/v2 v2.2.3
	github.com/riverqueue/river/riverdriver v0.50.0
	github.com/riverqueue/river/rivershared v0.50.0
	github.com/riverqueue/river/rivertype v0.50.0
	github.com/stretchr/testify v1.12.1
)

require (
	github.com/jackc/pgpassfile v1.0.0 // indirect
	github.com/jackc/pgservicefile v0.0.0-20240606120523-5a60cdf6a761 // indirect
	go.yaml.in/yaml/v3 v3.0.5 // indirect
	golang.org/x/sync v0.24.0 // indirect
	golang.org/x/text v0.43.0 // indirect
)
